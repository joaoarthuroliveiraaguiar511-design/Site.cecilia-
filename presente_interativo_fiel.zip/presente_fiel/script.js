const keypad=document.getElementById('keypad');
const dots=[...document.querySelectorAll('#dots i')];
const status=document.getElementById('status');
const phone=document.getElementById('phone');
const finish=document.getElementById('finishBtn');
const back=document.getElementById('backBtn');
const music=document.getElementById('musicBtn');
let entered='';
const password='1236';

[1,2,3,4,5,6,7,8,9].forEach(n=>makeKey(n));
makeKey(0,'zero');
makeKey('⌫','delete');
function makeKey(label,cls=''){
 const b=document.createElement('button');b.className='key '+cls;b.textContent=label;
 b.addEventListener('click',()=>{
   if(label==='⌫'){entered=entered.slice(0,-1)}else if(entered.length<4){entered+=String(label)}
   renderDots();
   b.classList.add('pressed');setTimeout(()=>b.classList.remove('pressed'),130);
   if(entered.length===4){
     if(entered===password){status.textContent='Correto';dots.forEach(d=>d.classList.add('filled'));setTimeout(()=>{phone.classList.add('done');status.textContent='Abrindo...'},450)}
     else{status.textContent='Tente novamente';phone.classList.add('pulse');setTimeout(()=>{entered='';renderDots();status.textContent='';phone.classList.remove('pulse')},700)}
   } else status.textContent='';
 });keypad.appendChild(b)
}
function renderDots(){dots.forEach((d,i)=>d.classList.toggle('filled',i<entered.length))}
finish.addEventListener('click',()=>{phone.classList.toggle('show-letter');if(phone.classList.contains('show-letter'))finish.textContent='Voltar para o jardim';else finish.textContent='Termine meu presente'});
back.addEventListener('click',()=>{phone.classList.remove('done','show-letter');entered='';renderDots();status.textContent='';});
music.addEventListener('click',()=>{music.textContent=music.textContent==='Ⅱ'?'▶':'Ⅱ';});
