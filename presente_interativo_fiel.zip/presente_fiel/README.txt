SITE INTERATIVO

Abra index.html para testar.
Senha do protótipo: 1236.

Para publicar: envie os arquivos desta pasta para um repositório do GitHub e ative GitHub Pages.
Não remova a pasta assets: as imagens são usadas pelo site.
